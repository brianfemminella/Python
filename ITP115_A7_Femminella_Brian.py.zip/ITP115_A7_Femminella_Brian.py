# Brian Femminella
# ITP 115, Fall 2019
# Assignment #7
#Rock, Paper, Scissors

import random

def displayMenu():
    print("The rules of the game are:")
    print("\tRock smashes scissors")
    print("\tScissors cut paper ")
    print("\tPaper covers rock")
    print("\tIf both the choices are the same, it's a tie")


def getComputerChoice():
    integerChoice = random.randrange(0,2)
    if (integerChoice == 0):
        print("The computer chose Rock")
    if (integerChoice == 1):
        print("The computer chose Paper")
    if (integerChoice == 2):
        print("The computer chose Scissors")
    return integerChoice

def getPlayerChoice():
    playerChoice = int(input("Please choose (0) for rock, (1) for paper or (2) for scissors"))
    if (playerChoice == 0):
        print("You chose Rock")
    if (playerChoice == 1):
        print("You chose Paper")
    if (playerChoice == 2):
        print("You chose Scissors")
    return playerChoice

def playRound(computerChoice, playerChoice):
    if (playerChoice == 0 and computerChoice == 2):
        print("Rock smashes scissors, player wins")
        return 1
    elif (playerChoice == 0 and computerChoice == 1):
        print("Paper covers rock, computer wins")
        return -1
    elif (playerChoice == 2 and computerChoice == 1):
        print("Scissors cuts paper, player wins")
        return 1
    elif (playerChoice == 2 and computerChoice == 0):
        print("Rock smashes scissors, computer wins")
        return -1
    elif (playerChoice == 1 and computerChoice == 0):
        print("Paper covers rock, player wins")
        return 1
    elif (playerChoice == 1 and computerChoice ==  2):
        print("Scissors cuts paper, computer wins")
        return -1
    elif (playerChoice == computerChoice):
        print("it's a tie")
        return 0

def continueGame():
    keepGoing = input("Do you want to continue playing? Enter (y) for yes or (n) for no. ")
    if (keepGoing == "Y" or keepGoing == "y"):
        return True
    if (keepGoing == "N" or keepGoing == "no"):
        return False


def main():
    keepGoing = True
    playerWins = 0
    computerWins = 0
    numberTies = 0

    while keepGoing == True:
        print("Welcome! Let's play rock, paper, scissors.")
        displayMenu()
        playerChoice = getPlayerChoice()
        computerChoice = getComputerChoice()
        result = playRound(computerChoice, playerChoice)
        if result == 1:
            playerWins += 1
        if result == -1:
            computerWins += 1
        if result == 0:
            numberTies += 1
        keepGoing = continueGame()
    print("You won " + str(playerWins) + " game(s)")
    print("The computer won " + str(computerWins) + " game(s)")
    print("You tied with the computer " + str(numberTies) + " time(s)")
    print("Thanks for playing!")
    
main()
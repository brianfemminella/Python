

from MenuItem import MenuItem

class Diner(object):
	STATUSES = ["seated","ordering","eating","paying","leaving"] #stuatuses static variable
	"""docstring for Diner"""
	DINING_SPEED = ["hurried","normal","slow"]
	def __init__(self, dinerName,speed): #constructor
		self.name = dinerName
		self.order = []
		self.status = 0
		self.diningSpeed = speed
		self.progress = speed

	#getter methods
	def getName(self):
		return self.name

	def getOrder(self):
		return self.order

	def getStatus(self):
		return Diner.STATUSES[self.status]

	def getSpeed(self):
		return self.diningSpeed

	def getProgress(self):
		return self.progress

	#setter methods
	def setName(self,newName):
		self.name = newName
		
	def setOrder(self,newOrder):
		self.order = newOrder

	def setStatus(self,newStatus):
		self.status = newStatus

	def setSpeed(self,newDiningSpeed):
		self.diningSpeed = newDiningSpeed

	def setProgress(self,newProgress):
		self.progress = newProgress

	#update Status
	def updateStatus(self):
		self.status += 1

	#update Progress
	def updateProgress(self):
		self.progress -= 1

	#adds a menuitem to the current order list
	def addToOrder(self,menuItem):
		self.order.append(menuItem)

	def printOrder(self):
		print("\n" + self.getName() + " Ordered: ")
		for i in self.order: #loops through items and prints them out using the __str__ method
			print("- " + i.__str__())

	def calculateMealCost(self):
		total = 0
		for i in self.order:
			total += i.getPrice(); #returns a total based on the cost of each menuItem
		return total

	def __str__(self):
		returnString = ""
		returnString += "Diner " + self.name + " is dining at a " + Diner.DINING_SPEED[self.diningSpeed] + " speed and is currently " + self.getStatus() + "."
		return returnString #concatenates a string to return for easy output
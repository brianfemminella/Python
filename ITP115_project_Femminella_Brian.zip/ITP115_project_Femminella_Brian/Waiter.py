
from Menu import Menu
from Diner import Diner

class Waiter(object):
	"""docstring for Waiter"""
	def __init__(self, menuObject): #constructor
		self.diners = [] #initialize blank diner list
		self.menu = menuObject #give the class a menu object to work with

	def addDiner(self,dinerObject):
		self.diners.append(dinerObject) #add a diner to the list

	def getNumDiners(self):
		count = 0
		for diner in self.diners: #loop through diners
			if diner is not None: #avoid fatal exceptions
				count += 1
		return count #return diner count

	def printDinerStatuses(self):
		for status in Diner.STATUSES: #loop through statuses
			print("Diners who are " + status.title() + ": ") #print out status
			for diner in self.diners: #loop through diners
				if diner is not None: #avoid fatal exceptions
					if diner.getStatus() == status: #print out diner if they are in the given status
						#print("\t" + diner.getName())
						print("\t" + diner.__str__())
	
	def takeOrders(self):
		for diner in self.diners: #loop through diners
			if diner is not None: #avoid fatal exceptions
				if diner.getStatus() == "ordering" and diner.getProgress() == 0: #if in correct dining state 
					for types in Menu.MENU_ITEM_TYPES:
						#print("\n" + diner.getName() + " Is Ordering...") #ordering state
						self.menu.printMenuItemsByType(types) #print out menu by item types
						print(diner.getName() + ", please select a " + types + " menu item number.")
						while True: #error checking
							try:
								selection = int(input("> ")) #prompt response
								if selection < 1 or selection > self.menu.getNumMenuItemsByType(types):
									raise ValueError #throws a ValueError if number is outside of range of given responses
								else:
									diner.addToOrder(self.menu.getMenuItem(types,(selection-1))) #else, add the item to the order
								break
							except ValueError: #catches bad input and reprompts an input
								#print("\t\tOops!  Bad Input.  Try again...")
								continue
					diner.printOrder() #once ordering is done, print out order

	def ringUpDiners(self):
		for diner in self.diners: #loop through diners
			if diner is not None: #avoid fatal exceptions
				if diner.getStatus() == "paying" and diner.getProgress() == 0: #if in correct dining state 
					cost = diner.calculateMealCost()
					print("\n{}, your meal cost ${:.2f}".format(diner.getName(),cost)) #format and print out cost for the diner

	def removeDoneDiners(self):
		for diner in self.diners: #loop through diners
			if diner is not None: #avoid fatal exceptions
				if diner.getStatus() == "leaving": #if in correct dining state 
					print("\n" + diner.getName() + ", thank you for dining with us! Come again soon!") #print out goodbye message
					self.diners.remove(diner) #remove diner from list

	def advanceDiners(self):
		self.printDinerStatuses() #call waiter methods
		self.takeOrders() #call waiter methods
		self.ringUpDiners() #call waiter methods
		self.removeDoneDiners() #call waiter methods
		for diner in self.diners: #loop through diners
			if diner is not None: #avoid fatal exceptions
				diner.updateProgress()
				if diner.getProgress() == -1:
					diner.updateStatus() #update/increment the status of each diner
					diner.setProgress(diner.getSpeed())

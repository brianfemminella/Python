
import csv #to read the csv data
from MenuItem import MenuItem

class Menu(object):
	MENU_ITEM_TYPES = ["Drink","Appetizer","Entree","Dessert"] #define static variable
	"""docstring for Menu"""
	def __init__(self, fileName): #constructor
		self.menuItemDictionary = {} #declare empty dictionary
		with open(fileName) as csv_file: #use csv reader to loop through .csv file
			readCSV = csv.reader(csv_file, delimiter=',') #split the file by ','
			#make and populate lists for different types
			drinks = []
			apps = []
			entrees = []
			desserts = []
			for row in readCSV:
				name = row[0]
				typeOfDish = row[1]
				price = row[2]
				description = row[3]
				newItem = MenuItem(name,typeOfDish,price,description)
				if typeOfDish == "Drink":
					drinks.append(newItem)
				elif typeOfDish == "Appetizer":
					apps.append(newItem)
				elif typeOfDish == "Entree":
					entrees.append(newItem)
				else:
					desserts.append(newItem)
			#populate the dictionary with the respective menuitem lists
			self.menuItemDictionary["Drink"] = drinks
			self.menuItemDictionary["Appetizer"] = apps
			self.menuItemDictionary["Entree"] = entrees
			self.menuItemDictionary["Dessert"] = desserts 
			#close the file
			csv_file.close()

	#get a menuitem
	def getMenuItem(self,menuType,index):
		return self.menuItemDictionary[menuType][index] #return the dictionary list value at the specified index

	#print a menuitem
	def printMenuItemsByType(self,menuType):
		print("\n-----" + menuType.upper() + "S-----") #print the type
		count = 1
		for item in self.menuItemDictionary[menuType]: #loop through and display a count before each one to make selection easy for diners
			print(str(count) + ") " + item.getName() + " (" + item.getType() + "): $" + str(item.getPrice()))
			print("\t" + item.getDescription())
			count += 1

	#get a menuitem given a specific type
	def getNumMenuItemsByType(self,menuType):
		amount = len(self.menuItemDictionary[menuType]) #amount is just the length of the type list
		return amount
		



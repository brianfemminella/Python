
class MenuItem(object):
	"""docstring for MenuItem"""
	#initiate instance variables
	def __init__(self, name, typeOfDish, price, description):
		self.name = name
		self.typeOfDish = typeOfDish
		self.price = price
		self.description = description

	#define getter methods
	def getName(self):
		return self.name

	def getType(self):
		return self.typeOfDish

	def getPrice(self):
		return float(self.price)

	def getDescription(self):
		return self.description

	#define setter methods
	def setName(self,newName):
		self.name = newName

	def setType(self,newType):
		self.typeOfDish = newType

	def setPrice(self,newPrice):
		self.price = newPrice

	def setDescription(self,newDescription):
		self.description = newDescription

	#toString method
	def __str__(self):
		returnString = ""
		returnString += self.name + " (" + self.typeOfDish + "): " + self.price + "\n\t" + self.description
		return returnString

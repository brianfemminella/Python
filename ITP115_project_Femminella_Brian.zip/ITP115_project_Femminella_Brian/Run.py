"""
ITP 115, Fall 2019 Final Project
Run this file in order to start the restaurant simulation program

"""
import datetime
import time

from Menu import Menu
from Waiter import Waiter
from RestaurantHelper import RestaurantHelper

def main():
    RESTAURANT_NAME = "PyPy's Diner"
    restaurantTime = datetime.datetime(2017, 5, 1, 5, 0)

    # Create the menu object
    menu = Menu("menu.csv")
    waiter = Waiter(menu)
    print("Welcome to " + RESTAURANT_NAME + "!")
    print(RESTAURANT_NAME + " is now open for dinner.\n")

    for i in range(21):
        print("\n~~~ It is currently", restaurantTime.strftime("%H:%M PM"), "~~~")
        restaurantTime += datetime.timedelta(minutes=15)

        potentialDiner = RestaurantHelper.randomDinerGenerator()
        if potentialDiner is not None:
            print("\n" + potentialDiner.getName() + " welcome, please be seated!\n")

        waiter.addDiner(potentialDiner)
        waiter.advanceDiners()
        time.sleep(2)

    print("\n~~~ ", RESTAURANT_NAME, "is now closed. ~~~")
    while waiter.getNumDiners():
        print("\n~~~ It is currently", restaurantTime.strftime("%H:%M PM"), "~~~")
        restaurantTime += datetime.timedelta(minutes=15)
        waiter.advanceDiners()
        time.sleep(2)

    print("Goodbye!")

main()

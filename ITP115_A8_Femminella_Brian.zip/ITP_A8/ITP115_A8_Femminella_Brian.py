# Brian Femminella
# ITP 115, Fall 2019
# Assignment #8
#Tic Tac Toe

import TicTacToeHelper

def isValidMove(boardList, spot):
    if (spot >= 0 and spot <= 8):
        if (boardList[spot] == "x" or boardList[spot] == "o"):
            return False
        return True
    return False


def updateBoard(boardList, spot, playerLetter):
    boardList[spot] = playerLetter


def playGame():
    boardList = ["0", "1", "2", "3", "4", "5", "6", "7", "8"]
    gameOver = False
    numMoves = 0
    xo = "x"
    print("Welcome to Tic Tac Toe!")
    TicTacToeHelper.printPrettyBoard(boardList)
    while (not (gameOver)):

        validMove = False
        while (not (validMove)):
            spot = int(input("Player " + xo + ", pick a spot: "))
            validMove = isValidMove(boardList, spot)
            if (not (validMove)):
                print("Invalid Move, please try again")
            else:
                validMove = True
        updateBoard(boardList, spot, xo)
        TicTacToeHelper.printPrettyBoard(boardList)

        winner = TicTacToeHelper.checkForWinner(boardList, numMoves)
        if (winner != "n"):
            print("Game Over!")
            print("Player " + xo + " is the winner!")
            gameOver = True
        if (numMoves % 2 == 0):
            xo = "o"
        if (numMoves % 2 == 1):
            xo = "x"
        numMoves += 1


def main():
    continueGame = True
    playGame()
    while True:
        continueGame = input("Would you like to play another round? (y/n): ")
        if continueGame == "y":
            playGame()
            continue
        if continueGame == "n":
            print("Goodbye!")
            break
        else:
            print("Invalid option")


main()
